import { Route } from '@angular/router';
import { ProductsComponent } from './products.component';
export const ProductsRoutes: Route[] = [
  {
    path: '',
    component: ProductsComponent
  }
];

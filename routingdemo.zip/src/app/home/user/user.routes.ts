import { Route } from '@angular/router';
import { UserComponent } from './user.component';
export const UserRoutes: Route[] = [
  {
    path: '',
    component: UserComponent
  }
];
